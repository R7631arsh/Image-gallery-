let currentIndex = 0;
let images = [];

function openLightbox(src) {
  images = Array.from(document.querySelectorAll('.gallery img')).map(img => img.src);
  currentIndex = images.indexOf(src);

  document.getElementById("lightbox-img").src = src;
  document.getElementById("lightbox").style.display = "flex";
}

function closeLightbox() {
  document.getElementById("lightbox").style.display = "none";
}

function changeImage(dir) {
  currentIndex = (currentIndex + dir + images.length) % images.length;
  document.getElementById("lightbox-img").src = images[currentIndex];
}

function filterImages(category) {
  const items = document.querySelectorAll('.img-item');
  items.forEach(item => {
    if (category === 'all' || item.classList.contains(category)) {
      item.style.display = 'block';
    } else {
      item.style.display = 'none';
    }
  });
}